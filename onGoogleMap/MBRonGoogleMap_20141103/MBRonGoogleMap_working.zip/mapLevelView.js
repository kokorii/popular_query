
/**********************************************************************
*initialize():
*페이지를 최초에 로드했을 때 실행되는 함수
***********************************************************************/
function initialize() {

	var tree = JSON.parse(HilbertPackTree);
	//최초 페이지에 보일 지도의  속성 정보
	//zoom은 global variable에서 지정한 레벨로 지정된다.
	//center : 최초에 보일 지도의 중심 좌표는 서울로 임의 설정하였다.
	//mapTypeId : google Map에서 지원하는 map의 type으로 단순 ROADMAP으로 임의 설정하였다.
	

	//ROOT NODE들이 가지고있는 entry의 MBR들을 지도 위에 그려 줄 함수.
	//최초에 페이지가 로드되면 지도 위에 ROOT NODE들의 Entry 개수만큼 MBR이 보여야 한다.
	
	showStart(tree);
}

/**********************************************************************
*showStart()
*지도위에 사각형을 보여주는 작업을 시작하는 함수이다.
*Root Node가 가지고있는 entry의 수만큼 rectangle 배열에 저장하고 그린다.
*저장된 rectangle들에는 event handler를 달아서
*click 된  사각형의 child node entry들을 display할 수 있도록 한다.
***********************************************************************/
function showStart(tree) {

	var seoul = new google.maps.LatLng(36.314141, 127.992776);
	
	var map = reMap();
	map.setCenter(seoul);
	
	drawingTool(tree, map);	  
	
	stroke = fill = randColor();
	
	var rectangle = new Array();

	for(var i=0; i<tree.length; i++){			
	
		var mbr = getMyMBR(tree, i);

		rectangle[i] = drawRectangle(map, mbr, stroke, fill);
		
		var cData = tree[i];
		
		Listener(tree, cData, rectangle[i]);
		
	}
}

function Listener(tree, Data, clickedRect){

	google.maps.event.addListener(clickedRect, 'click', 
			
			function(){ 
				
				if(Data.level <= 0){
					alert("this is leaf node\n");
					return;
				}
				
				var map = reMap();	

				var centerX = ((Data.Xl+Data.Xh)/2);
				var centerY = ((Data.Yl+Data.Yh)/2);
				var newCenter = reCentering(centerX, centerY);

				map.setCenter(newCenter);
				
				drawingTool(tree, map);
				
				zoomLevel = zoomLevel + 1;
				
				map.setZoom(zoomLevel);
				
				
				stroke = fill = randColor();
				
				var rect = new Array();

				for(var j=0; j<Data.child.length; j++){
					
					var mbr = getChildMBR(Data, j);
					 
					rect[j] = drawRectangle(map, mbr, stroke, fill);
					
					var cData = Data.child[j];
					
					Listener(tree, cData, rect[j]);
				}								
			});
}

//window가 load되면 initialize 함수 실행
google.maps.event.addDomListener(window, 'load', initialize);