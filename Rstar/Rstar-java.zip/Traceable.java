public interface Traceable
{
    public abstract void    setTraceable(boolean enable);
    public abstract boolean isTraceable();
}