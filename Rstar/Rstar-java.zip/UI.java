public class UI {

    public static void main(String argv[]) {
        UserInterface ui = new UserInterface();
        ui.show();
    }
}
